require 'json'
require 'uri'
require 'net/http'

spark_master_guid = `cf app spark-master --guid`.chomp
spark_worker_guid = `cf app spark-worker --guid`.chomp
authorization = `cf oauth-token`.chomp

policies = ([7077, 8080] + (30000..65535).to_a).flat_map do |port|
    [
        { 
            "source" => { "id" => spark_master_guid },
            "destination" => { "id" => spark_worker_guid, "port" => port, "protocol" => "tcp" },
        },
        { 
            "source" => { "id" => spark_worker_guid },
            "destination" => { "id" => spark_master_guid, "port" => port, "protocol" => "tcp" },
        },
    ]
end

uri = URI.parse("http://api.#{ARGV[0]}.xip.io/networking/v0/external/policies")
http = Net::HTTP.new(uri.host, uri.port)
http.read_timeout = 300
req = Net::HTTP::Post.new(uri.path, initheader = {
    'Accept' => 'application/json',
    'Content-Type' => 'application/json',
    'Authorization' => authorization,
})
req.body = { "policies" => policies }.to_json
res = http.request(req)